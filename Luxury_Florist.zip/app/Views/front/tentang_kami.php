<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
  <!--begin::Entry-->
  <div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
      <!--begin::Page Layout-->
      <div class="d-flex flex-row">
        <!--begin::Aside-->
        <!-- <div class="flex-column offcanvas-mobile w-300px w-xl-325px" id="kt_profile_aside">
        </div> -->
        <!--end::Aside-->
        <!--begin::Layout-->
        <div class="flex-row-fluid ml-lg-12 lg-12">
          <!--begin::Section-->
          <div class="card card-custom card-transparent">
            <div class="card-body p-0">
              <!--begin: Wizard-->

              <!--end: Wizard Nav-->
              <!--begin: Wizard Body-->
              <div class="card card-custom card-shadowless rounded-top-0">
                <div class="card-header text-center align-center">
                  <div class="col-md-12">
                    <br>
                    <center>
                      <h2>Tentang Kami :</h2>
                    </center>
                  </div>
                </div>

                <div class="card-body p-0">
                  <table class="table">
                    <tr>
                      <td>Luxury Florist yang didirikan oleh Fadly Prakasa pada tahun 2012 yang beralamat PS. Ambacang, kec kuranji, kota Padang, Sumbar</td>

                    </tr>

                  </table>
                </div>
                <br><br><br>
              </div>
              <!--end: Wizard Bpdy-->

              <!--end: Wizard-->
            </div>
          </div>
          <!--end::Section-->
        </div>
        <!--end::Layout-->
      </div>
      <!--end::Page Layout-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div>
<!--end::Content-->