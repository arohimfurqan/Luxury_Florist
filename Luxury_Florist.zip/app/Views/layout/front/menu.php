			<!--begin::Header Menu Wrapper-->
			<div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
				<!--begin::Header Menu-->
				<div id="kt_header_menu" class="header-menu header-menu-left header-menu-mobile header-menu-layout-default">
					<!--begin::Header Nav-->
					<ul class="menu-nav">
						<li class="menu-item  ">
							<a href="<?= BASE ?>" class="menu-link ">
								<span class="menu-text">Home</span>
								<i class="menu-arrow"></i>
							</a>

						</li>



						<li class="menu-item menu-item-submenu menu-item-rel">
							<a href="#" class="menu-link menu-toggle">
								<span class="menu-text">Kategori</span>
								<i class="menu-arrow"></i>
							</a>

						</li>

						<li class="menu-item menu-item-submenu menu-item-rel">
							<a href="#" class="menu-link menu-toggle">
								<span class="menu-text">Tentang Kami</span>
								<i class="menu-arrow"></i>
							</a>

						</li>

						<li class="menu-item menu-item-submenu menu-item-rel">
							<a href="#" class="menu-link menu-toggle">
								<span class="menu-text">Kontak Kami</span>
								<i class="menu-arrow"></i>
							</a>

						</li>

					</ul>
					<!--end::Header Nav-->
				</div>
				<!--end::Header Menu-->
			</div>
			<!--end::Header Menu Wrapper-->